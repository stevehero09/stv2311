({
	onClick: function(component, event, helper) {
		var navigate = component.get('v.navigateFlow');
        
        navigate('NEXT');
	}
})